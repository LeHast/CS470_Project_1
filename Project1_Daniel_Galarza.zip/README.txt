- Project 1.

- Daniel Galarza

- To run the program is require to have the next files in the same directory
as the main.js file:
	cs_prerequisites.json

Use the next command and add two arguments to run the program,
those arguments needs to be only the class numbers, for example: 
	node main.js 315 415